# Whatsapp
A dark and simple Whatsapp Client for Linux

App made with electron

**// Installation**

Download "Whatsapp-linux-x64.tar.gz"

extract it to "/opt/Whatsapp-linux-x64"

execute with "/opt/Whatsapp-linux-x64/Whatsapp"

Use https://github.com/donadigo/appeditor 
to create a shortcut or use a similar app, or do it from scratch
